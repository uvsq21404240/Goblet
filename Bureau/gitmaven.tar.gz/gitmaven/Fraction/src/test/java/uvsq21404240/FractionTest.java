package uvsq21404240;

import static org.junit.Assert.*;
import org.junit.Test;

public class FractionTest {



}

