Se positionner sur le répertoire du projet et :

	- Pour compiler une classe quelconque : javac -d bin src/NomClasse.java
	- Pour compiler la classe principale : javac -d bin -cp bin src/NomClassePrincipale.java
	- Pour executer le programme : java -cp bin NomClassePrincipale
