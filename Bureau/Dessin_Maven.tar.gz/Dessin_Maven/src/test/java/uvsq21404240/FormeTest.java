package uvsq21404240;

import static org.junit.Assert.*;
import org.junit.Test;

public class FormeTest {
	
	
	@Test
	public void testConstructeur()
	{
	Forme a = new Forme("a" , 1 , 1);
	int abc ;
	int bca ;
	abc = a.getx();
	bca = a.gety();
	assertTrue("Vrai", abc == 1 );
	}
	@Test
	public void testget()
	{
	Forme a = new Forme("a" , 1 , 2);
	int abc ;
	int bca ;
	abc = a.getx();
	bca = a.gety();
	assertTrue("Vrai", bca == 2 );
	}

	

}

