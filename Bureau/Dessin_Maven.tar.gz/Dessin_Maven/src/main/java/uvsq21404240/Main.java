package uvsq21404240;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) 
		{
		int i = 0;
		int j = 0;
		Saisie s = new Saisie();
		while (i == 0)
			{
			j++ ;
			 System.out.println("numero d'iteration :" + j );
			s.s();
			}
		}
		
}

	

