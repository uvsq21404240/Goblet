package uvsq21404240;
import java.io.*;
public class FormeDessin implements Serializable {
	public Forme T[][] = new Forme[10][10];
	public FormeDessin() {
		for (int i = 0; i < 10 ; i++)
		{	for (int j = 0; j < 10 ; j++)
			{
				T[i][j] = new Forme("[0]",i,j);
			}
		}
	}
	public void modifivaleurlocal(FormeDessin azerty, int a , int b , int c , int d)
	{
		azerty.T[a][b].afficher();
	}
	public void add(String type,int x,int y)
	{
		try{
		T[x][y] = new Forme(type,x,y);
	}
	 catch (ArrayIndexOutOfBoundsException out)
               {
                  System.out.println("Erreur --Tentative d'ajout d'un onzième élément dans un tableau qui ne peut en contenir que 10...");
               }
	}
	public void afficher()
	{
		for (int i = 0; i <10 ; i++)
		{	for (int j = 0; j <10 ; j++)
			{
				System.out.print(T[i][j].afficher());
			}
			System.out.println();
		}
	}
/***Open classrom ***/
	public void sauvgarder()
	{
		ObjectOutputStream sortie;
		try{
			sortie = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File("texte.txt"))));
			sortie.writeObject(this);
			sortie.close();
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();}
	}
	public void charger()
	{
		ObjectInputStream entree;
		try{
			entree = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("texte.txt"))));
			try {
				((FormeDessin)entree.readObject()).afficher();
			} 
			catch (ClassNotFoundException e) {
				e.printStackTrace();}
				entree.close();
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();}
	}
}

