package uvsq21404240;
import java.util.LinkedList;

public class Ensemble {
	public LinkedList l;
	
	public Ensemble() {
		l = new LinkedList();
	}
	public void ajouter(Forme f)
	{
		l.add(f);
	}
	public void recup(Forme f, int a)
	{
		l.get(a);
	}
	public void deplacer(FormeDessin fd,int dx, int dy) {
		for (int i = 0; i < l.size() ; i++)
		{
			int x = ((Forme) l.get(i)).x;
			int y = ((Forme) l.get(i)).y;
			String forme = ((Forme) l.get(i)).forme;
			fd.T[x][y] = new Forme("[0]");
			((Forme) l.get(i)).deplacer(dx,dy);
			fd.T[x+dx][y+dy] = new Forme(forme);
		}
	}
	public LinkedList ToString()
	{
		return l;
	}
}

