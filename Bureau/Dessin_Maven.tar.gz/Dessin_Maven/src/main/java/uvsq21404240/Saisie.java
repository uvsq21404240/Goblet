package uvsq21404240;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
public class Saisie implements Serializable{
	private Scanner sc;
	public int x, y , r;
	public int x1, y1 ;
	public ObjectInputStream ois;
	public ObjectOutputStream oos;	
	public FormeDessin fd;
	public Ensemble E;
	public String signe;
	public Saisie(){
	sc = new Scanner(System.in);
	this.fd = new FormeDessin();
	this.E = new Ensemble();
	}
	public void s(){
		System.out.println("Veuillez saisir un choix:");
		System.out.println("1 pour créer une forme");
		System.out.println("2 pour modifier une forme");
		if(sc.hasNextInt())
		{
			int a = sc.nextInt();
			if(a == 1)
			{
				System.out.println("Veuillez saisir un choix:");
				System.out.println("1 pour créer une forme");
				System.out.println("2 pour rien faire");
				a = sc.nextInt();
				if(a == 1)
				{
					System.out.println("Choisir le x :");
					x = sc.nextInt();
					System.out.println("Choisir le y :");
					y = sc.nextInt();
					System.out.println("Choisir le type :");
					sc.nextLine();
					signe = sc.nextLine();
					System.out.println("Vous avez saisi : " + signe);
					fd.add(signe,x,y);
					fd.afficher();
					fd.sauvgarder();
				}
				else
				{
					System.out.println("erreur de saisie: 2");
				}
			}
			if(a == 2)
			{
				System.out.println("Voici votre structure:");
				System.out.println("\n");
				fd.charger();
				System.out.println("Veuillez saisir un choix:");
				System.out.println("1 pour modifier une forme");
				System.out.println("2 pour rien faire");
				a = sc.nextInt();
				if(a == 1)
				{
					int abc = 1;
						while (abc == 1)
						{
							System.out.println("Veuillez saisir un choix:");
							System.out.println("1 pour choisire une forme a modifier");
							System.out.println("2 pour choisire la derniére forme");
							abc = sc.nextInt();
							System.out.println("Choisir le x :");
							x = sc.nextInt();
							System.out.println("Choisir le y :");
							y = sc.nextInt();
							E.ajouter(fd.T[x][y]);
						}
						System.out.println("Choisir la modification en x et y");
						System.out.println("Choisir le x :");
						x = sc.nextInt();
						System.out.println("Choisir le y :");
						y = sc.nextInt();
						E.deplacer(fd,x,y);
						fd.afficher();
				}
			}
		}
		else
		{
			System.out.println("refaire une saisie");		
		}
		
	}
}


