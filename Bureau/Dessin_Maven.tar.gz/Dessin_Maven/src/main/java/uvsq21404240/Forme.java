package uvsq21404240;
import java.io.Serializable;
/*
public class Forme implements Serializable{
	private String nom;
	public int type;
    public String getNom(){ 
		return nom;
	}
    public void setNom(String nom){ 
		this.nom = nom; 
	}
}
*/
public class Forme implements Serializable  {
	public String forme;
	public int x;
	public int y;
	public Forme(String nom)
	{
		this.forme = nom;
		this.x = 0;
		this.y = 0;
	}
	public Forme(String nom, int x, int y)
	{
		this.forme = nom;
		this.x = x;
		this.y = y;
	}
	public void deplacer(int dx,int dy) 
	{	
		if ((dx + x)<10 && (dy + y)<10)
		{
		x = x + dx;
		y = y + dy;
	}
	else 
	{
		System.out.println("erreur vous aller sortir du tableau");
	}
	}
	public String afficher() 
	{
		return this.forme+"  ";
	}
	public int getx(){
		return this.x;
	}
	public int gety(){
		return this.y;
	}
}

