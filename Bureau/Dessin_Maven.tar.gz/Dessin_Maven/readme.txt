java -cp target/Main-0.0.1-SNAPSHOT.jar uvsq21404240.Main
java -cp target/Main-0.0.1-SNAPSHOT.jar uvsq21404240.Main


Commande pour compiler
